# Biblio Topic Search

Biblio Topic Search este o aplicație Android pentru cercetare rapidă în cărți și alte surse fizice, folosind OCR live pe cameră. Aplicația nu decide semantic ce este relevant: utilizatorul definește exact termenii de căutat și îi organizează într-o hartă flexibilă de noduri și subnoduri.

## Ce face

- OCR live pe cameră, local pe dispozitiv.
- Caută simultan termenii din nodurile active.
- Harta nu conține categorii prestabilite: pornește goală.
- Poți adăuga un nod principal cu `+ NOD PRINCIPAL` și un subnod direct din cardul oricărui nod.
- Poți folosi oricâte niveluri de ierarhie ai nevoie.
- Fiecare nod are culoare, simbol și stare activă proprie.
- Poți activa/dezactiva noduri, niveluri întregi sau folosi `DOAR` pentru un singur nod.
- Harta poate fi scrisă manual sau încărcată din TXT, MD ori DOCX.
- Potriviri: Exact / Începe cu / Conține.
- Poți limita comparația la primele N caractere și poți ignora diacriticele.
- Pe cameră, termenul căutat apare într-o etichetă colorată lângă locul unde a fost găsit, împreună cu nodul/subnodul lui.
- Highlight-ul este stabilizat între cadre pentru a rămâne cât mai bine ancorat pe text.
- Cadrul poate fi înghețat și salvat explicit.
- Lanternă integrată.
- Dicționar CSV local opțional.
- Aplicația nu cere permisiunea INTERNET.

## Formatul hărții

Numărul de `#` stabilește nivelul nodului. Termenii sunt scriși sub nod și pot fi separați cu `|`.

```text
# Nod principal
termen | expresie
## Subnod
alt termen
### Nivel următor
termen specific
```

Acest format rămâne editabil direct, chiar dacă folosești butoanele de adăugare din aplicație.

## Încărcarea unei hărți

În ecranul `HARTĂ`, folosește `ÎNCARCĂ DOCUMENT`. Sunt acceptate documente text TXT/MD și DOCX. Pentru un PDF, exportă mai întâi conținutul hărții ca TXT, MD sau DOCX, pentru ca structura `# / ## / ###` să rămână explicită.

## Dicționar local

Format CSV:

```text
term,definition,synonyms,antonyms,source
```

Dicționarul rămâne local pe telefon.

## Build în GitHub

1. Dezarhivează pachetul.
2. Încarcă în repository **conținutul** folderului, astfel încât `app/`, `.github/`, `build.gradle.kts` și `settings.gradle.kts` să fie direct în rădăcina repository-ului.
3. Deschide `Actions`.
4. Rulează workflow-ul `Build BiblioTopicSearch APK`.
5. Descarcă artefactul `BiblioTopicSearch-APK`; în el se află `BiblioTopicSearch.apk`.

## Tehnic

- Java 17
- Android API 36
- Android Gradle Plugin 8.13.2
- CameraX 1.6.1
- ML Kit Text Recognition bundled (`com.google.mlkit:text-recognition:16.0.1`)
- minSdk 23
- orientare portret

## Confidențialitate

Aplicația nu are permisiunea INTERNET. Hărțile, setările și dicționarul rămân local pe telefon. Camera nu este înregistrată și nu se salvează automat.
