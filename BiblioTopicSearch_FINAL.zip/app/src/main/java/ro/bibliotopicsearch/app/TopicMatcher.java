package ro.bibliotopicsearch.app;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.RectF;

import com.google.mlkit.vision.text.Text;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class TopicMatcher {
    private TopicMatcher() {}

    public static List<MatchHit> find(Context context, Text text, TopicMap map) {
        List<MatchHit> hits = new ArrayList<>();
        if (text == null || map == null || map.nodes.isEmpty()) return hits;

        boolean stripDiacritics = AppPrefs.ignoreDiacritics(context);
        int compareChars = AppPrefs.compareChars(context);
        AppPrefs.MatchMode mode = AppPrefs.getMatchMode(context);
        long now = System.currentTimeMillis();
        Set<String> dedupe = new HashSet<>();

        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                List<Text.Element> elements = line.getElements();
                if (elements == null || elements.isEmpty()) continue;

                for (TopicNode node : map.nodes) {
                    if (!node.enabled) continue;

                    // Dacă utilizatorul a creat un nod dar nu a adăugat încă
                    // termeni separați, titlul nodului este folosit ca termen
                    // de rezervă. Nu se inventează nimic: este chiar textul
                    // introdus explicit de utilizator.
                    List<String> searchTerms = node.terms.isEmpty()
                            ? java.util.Collections.singletonList(node.title)
                            : node.terms;

                    for (String rawTerm : searchTerms) {
                        String normalizedTerm = normalize(rawTerm, stripDiacritics);
                        if (normalizedTerm.isEmpty()) continue;

                        int tokenCount = Math.max(1, normalizedTerm.split("\\s+").length);
                        if (tokenCount <= 1) {
                            for (Text.Element element : elements) {
                                Rect box = element.getBoundingBox();
                                if (box == null) continue;

                                String actual = normalize(element.getText(), stripDiacritics);
                                if (matches(actual, normalizedTerm, mode, compareChars)) {
                                    addHit(hits, dedupe, new RectF(box), element.getText(), rawTerm, node, now);
                                }
                            }
                        } else {
                            for (int start = 0; start < elements.size(); start++) {
                                int endExclusive = Math.min(elements.size(), start + tokenCount);
                                if (endExclusive - start < tokenCount) break;

                                StringBuilder phrase = new StringBuilder();
                                RectF union = null;
                                StringBuilder original = new StringBuilder();

                                for (int i = start; i < endExclusive; i++) {
                                    Text.Element element = elements.get(i);
                                    Rect box = element.getBoundingBox();
                                    if (box == null) {
                                        union = null;
                                        break;
                                    }
                                    if (phrase.length() > 0) {
                                        phrase.append(' ');
                                        original.append(' ');
                                    }
                                    phrase.append(normalize(element.getText(), stripDiacritics));
                                    original.append(element.getText());

                                    if (union == null) {
                                        union = new RectF(box);
                                    } else {
                                        union.union(new RectF(box));
                                    }
                                }

                                if (union != null && matches(phrase.toString(), normalizedTerm, mode, compareChars)) {
                                    addHit(hits, dedupe, union, original.toString(), rawTerm, node, now);
                                }
                            }
                        }
                    }
                }
            }
        }
        return hits;
    }

    private static void addHit(
            List<MatchHit> hits,
            Set<String> dedupe,
            RectF box,
            String original,
            String searchTerm,
            TopicNode node,
            long timestamp
    ) {
        int cx = Math.round(box.centerX() / 4f);
        int cy = Math.round(box.centerY() / 4f);
        String key = node.path + "|" + searchTerm + "|" + cx + "|" + cy;
        if (dedupe.add(key)) {
            hits.add(new MatchHit(box, original, searchTerm, node, timestamp));
        }
    }

    public static boolean matches(
            String actual,
            String term,
            AppPrefs.MatchMode mode,
            int compareChars
    ) {
        if (actual == null || term == null) return false;
        String a = actual.trim();
        String t = term.trim();
        if (a.isEmpty() || t.isEmpty()) return false;

        if (compareChars > 0) {
            int tLen = Math.min(compareChars, t.length());
            t = t.substring(0, tLen);

            if (mode == AppPrefs.MatchMode.EXACT) {
                int aLen = Math.min(compareChars, a.length());
                a = a.substring(0, aLen);
            }
        }

        switch (mode) {
            case EXACT:
                return a.equals(t);
            case CONTAINS:
                return a.contains(t);
            case PREFIX:
            default:
                return a.startsWith(t);
        }
    }

    public static String normalize(String value, boolean stripDiacritics) {
        if (value == null) return "";
        String out = value.toLowerCase(Locale.ROOT).trim();

        if (stripDiacritics) {
            out = Normalizer.normalize(out, Normalizer.Form.NFD)
                    .replaceAll("\\p{M}+", "");
        }

        out = out
                .replaceAll("[^\\p{L}\\p{N}\\s'-]+", " ")
                .replaceAll("\\s+", " ")
                .trim();

        return out;
    }
}
