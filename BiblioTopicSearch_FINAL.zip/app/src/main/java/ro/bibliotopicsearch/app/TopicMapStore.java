package ro.bibliotopicsearch.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class TopicMapStore {
    private static final String PREF_FILE = "bibliotopicsearch_map";

    private static final int[] DEFAULT_COLORS = new int[] {
            Color.rgb(218, 73, 96),
            Color.rgb(48, 129, 157),
            Color.rgb(58, 146, 114),
            Color.rgb(222, 148, 54),
            Color.rgb(127, 90, 168),
            Color.rgb(76, 112, 157),
            Color.rgb(190, 91, 55),
            Color.rgb(82, 142, 63),
            Color.rgb(184, 72, 143),
            Color.rgb(61, 150, 148),
            Color.rgb(112, 98, 79),
            Color.rgb(192, 116, 35)
    };

    // Aplicația pornește cu o hartă goală. Nu există categorii sau noduri prestabilite.
    public static final String DEFAULT_MAP = "";

    // Amprenta hărții demonstrative din versiunea anterioară. Păstrăm numai
    // hash-ul pentru migrare, nu și vechile categorii în aplicația nouă.
    private static final String LEGACY_DEFAULT_MAP_KEY = "229544ec885cd448";

    private TopicMapStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE);
    }

    public static String getMapName(Context context) {
        return prefs(context).getString("map_name", "Hartă de cercetare");
    }

    public static String getRawMap(Context context) {
        SharedPreferences preferences = prefs(context);
        String stored = preferences.getString("map_text", DEFAULT_MAP);
        if (stored != null && LEGACY_DEFAULT_MAP_KEY.equals(key(stored))) {
            preferences.edit().putString("map_text", DEFAULT_MAP).apply();
            return DEFAULT_MAP;
        }
        return stored == null ? DEFAULT_MAP : stored;
    }

    public static void saveMap(Context context, String name, String text) {
        prefs(context).edit()
                .putString("map_name", safe(name, "Hartă de cercetare"))
                .putString("map_text", text == null ? "" : text)
                .apply();
    }

    public static TopicMap load(Context context) {
        return parse(context, getMapName(context), getRawMap(context));
    }

    public static TopicMap parse(Context context, String name, String rawText) {
        List<TopicNode> nodes = new ArrayList<>();
        Map<Integer, String> hierarchy = new LinkedHashMap<>();
        TopicNode current = null;
        String[] lines = (rawText == null ? "" : rawText).split("\\r?\\n");

        for (String sourceLine : lines) {
            String line = sourceLine == null ? "" : sourceLine.trim();
            if (line.isEmpty()) continue;

            if (line.startsWith("#")) {
                int level = 0;
                while (level < line.length() && line.charAt(level) == '#') {
                    level++;
                }
                String title = line.substring(level).trim();
                if (title.isEmpty()) title = "Nod " + (nodes.size() + 1);

                List<Integer> remove = new ArrayList<>();
                for (Integer existingLevel : hierarchy.keySet()) {
                    if (existingLevel >= level) remove.add(existingLevel);
                }
                for (Integer removeLevel : remove) hierarchy.remove(removeLevel);
                hierarchy.put(level, title);

                StringBuilder path = new StringBuilder();
                for (Map.Entry<Integer, String> entry : hierarchy.entrySet()) {
                    if (path.length() > 0) path.append(" > ");
                    path.append(entry.getValue());
                }

                current = new TopicNode(path.toString(), title, level);
                int defaultColor = DEFAULT_COLORS[nodes.size() % DEFAULT_COLORS.length];
                current.color = getNodeColor(context, current.path, defaultColor);
                current.symbol = getNodeSymbol(context, current.path, defaultSymbol(level));
                current.enabled = getNodeEnabled(context, current.path, true);
                nodes.add(current);
                continue;
            }

            // Termenii aparțin întotdeauna unui nod creat explicit de utilizator.
            // Liniile aflate înaintea primului titlu sunt ignorate, ca aplicația
            // să nu inventeze automat niciun nod sau categorie.
            if (current == null) continue;

            String termLine = line;
            if (termLine.startsWith("- ") || termLine.startsWith("• ")) {
                termLine = termLine.substring(2).trim();
            }

            String[] pieces = termLine.split("\\|");
            for (String piece : pieces) {
                String term = piece.trim();
                if (!term.isEmpty() && !current.terms.contains(term)) {
                    current.terms.add(term);
                }
            }
        }

        return new TopicMap(safe(name, "Hartă de cercetare"), rawText == null ? "" : rawText, nodes);
    }

    public static void setNodeColor(Context context, String path, int color) {
        prefs(context).edit().putInt("node_" + key(path) + "_color", color).apply();
    }

    public static int getNodeColor(Context context, String path, int defaultColor) {
        return prefs(context).getInt("node_" + key(path) + "_color", defaultColor);
    }

    public static void setNodeSymbol(Context context, String path, String symbol) {
        prefs(context).edit().putString("node_" + key(path) + "_symbol", symbol == null ? "" : symbol).apply();
    }

    public static String getNodeSymbol(Context context, String path, String defaultSymbol) {
        return prefs(context).getString("node_" + key(path) + "_symbol", defaultSymbol);
    }

    public static void setNodeEnabled(Context context, String path, boolean enabled) {
        prefs(context).edit().putBoolean("node_" + key(path) + "_enabled", enabled).apply();
    }

    public static boolean getNodeEnabled(Context context, String path, boolean defaultValue) {
        return prefs(context).getBoolean("node_" + key(path) + "_enabled", defaultValue);
    }

    public static void setAllEnabled(Context context, TopicMap map, boolean enabled) {
        SharedPreferences.Editor editor = prefs(context).edit();
        for (TopicNode node : map.nodes) {
            editor.putBoolean("node_" + key(node.path) + "_enabled", enabled);
        }
        editor.apply();
    }

    public static void setOnlyNode(Context context, TopicMap map, String path) {
        SharedPreferences.Editor editor = prefs(context).edit();
        for (TopicNode node : map.nodes) {
            editor.putBoolean("node_" + key(node.path) + "_enabled", node.path.equals(path));
        }
        editor.apply();
    }


    public static void setLevelEnabled(Context context, TopicMap map, int level, boolean enabled) {
        SharedPreferences.Editor editor = prefs(context).edit();
        for (TopicNode node : map.nodes) {
            if (node.level == level) {
                editor.putBoolean("node_" + key(node.path) + "_enabled", enabled);
            }
        }
        editor.apply();
    }

    private static String defaultSymbol(int level) {
        String[] symbols = {"●", "◆", "■", "▲", "✦", "✚", "◉", "◇"};
        return symbols[Math.max(0, level - 1) % symbols.length];
    }

    private static String key(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < 8 && i < bytes.length; i++) {
                out.append(String.format(Locale.ROOT, "%02x", bytes[i]));
            }
            return out.toString();
        } catch (Exception ignored) {
            return Integer.toHexString(value.hashCode());
        }
    }

    private static String safe(String value, String fallback) {
        if (value == null || value.trim().isEmpty()) return fallback;
        return value.trim();
    }
}
