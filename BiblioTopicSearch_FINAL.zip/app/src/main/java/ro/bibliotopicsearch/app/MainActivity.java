package ro.bibliotopicsearch.app;

import static androidx.camera.core.ImageAnalysis.COORDINATE_SYSTEM_VIEW_REFERENCED;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.net.Uri;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.mlkit.vision.MlKitAnalyzer;
import androidx.camera.view.LifecycleCameraController;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.OutputStream;

public final class MainActivity extends AppCompatActivity {
    private static final int REQ_CAMERA = 101;
    private static final int REQ_SAVE_FRAME = 501;

    private PreviewView previewView;
    private ImageView freezeImage;
    private OverlayView overlayView;
    private TextView mapTitle;
    private TextView statusText;
    private Button freezeButton;
    private Button torchButton;

    private LifecycleCameraController cameraController;
    private TextRecognizer recognizer;
    private final ExecutorService analysisExecutor = Executors.newSingleThreadExecutor();

    private TopicMap topicMap;
    private boolean frozen = false;
    private boolean torchEnabled = false;
    private Bitmap frozenBitmap;
    private ToneGenerator toneGenerator;
    private long lastFeedbackAt = 0L;
    private String lastFeedbackSignature = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        toneGenerator = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 22);

        overlayView.setOnHitTapListener(this::showHitDetails);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            setupCamera();
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.CAMERA},
                    REQ_CAMERA
            );
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        topicMap = TopicMapStore.load(this);
        if (mapTitle != null) {
            mapTitle.setText(topicMap.name + " • " + activeNodeCount(topicMap) + " noduri active");
        }
        if (overlayView != null) {
            overlayView.updateHits(
                    overlayView.getHitsSnapshot(),
                    AppPrefs.precision(this),
                    AppPrefs.showLabels(this)
            );
        }
    }

    @Override
    protected void onDestroy() {
        if (cameraController != null) {
            cameraController.clearImageAnalysisAnalyzer();
            cameraController.unbind();
        }
        if (recognizer != null) recognizer.close();
        analysisExecutor.shutdown();
        if (toneGenerator != null) toneGenerator.release();
        super.onDestroy();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        previewView = new PreviewView(this);
        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(previewView, match());

        freezeImage = new ImageView(this);
        freezeImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        freezeImage.setBackgroundColor(Color.BLACK);
        freezeImage.setVisibility(View.GONE);
        root.addView(freezeImage, match());

        overlayView = new OverlayView(this);
        root.addView(overlayView, match());

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(12), dp(8), dp(12), dp(8));
        top.setBackgroundColor(Color.argb(215, 27, 39, 51));

        TextView appTitle = new TextView(this);
        appTitle.setText("Biblio Topic Search");
        appTitle.setTextColor(Color.WHITE);
        appTitle.setTextSize(19);
        appTitle.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        top.addView(appTitle);

        mapTitle = new TextView(this);
        mapTitle.setTextColor(Color.rgb(222, 230, 236));
        mapTitle.setTextSize(12);
        top.addView(mapTitle);

        statusText = new TextView(this);
        statusText.setText("Pregătit • camera OCR este locală");
        statusText.setTextColor(Color.rgb(244, 240, 230));
        statusText.setTextSize(12);
        statusText.setPadding(0, dp(3), 0, 0);
        top.addView(statusText);

        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
        );
        root.addView(top, topLp);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setPadding(dp(5), dp(5), dp(5), dp(8));
        bottom.setBackgroundColor(Color.argb(225, 27, 39, 51));

        Button mapButton = actionButton("HARTĂ");
        freezeButton = actionButton("ÎNGHEAȚĂ");
        Button saveButton = actionButton("SALVEAZĂ");
        torchButton = actionButton("LANTERNĂ");
        Button settingsButton = actionButton("SETĂRI");

        bottom.addView(mapButton, weightedButton());
        bottom.addView(freezeButton, weightedButton());
        bottom.addView(saveButton, weightedButton());
        bottom.addView(torchButton, weightedButton());
        bottom.addView(settingsButton, weightedButton());

        FrameLayout.LayoutParams bottomLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
        );
        root.addView(bottom, bottomLp);

        mapButton.setOnClickListener(v ->
                startActivity(new Intent(this, MapEditorActivity.class)));

        settingsButton.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));

        freezeButton.setOnClickListener(v -> toggleFreeze());
        saveButton.setOnClickListener(v -> saveFrozenFrame());
        torchButton.setOnClickListener(v -> toggleTorch());

        setContentView(root);
    }

    private void setupCamera() {
        if (cameraController != null) return;

        cameraController = new LifecycleCameraController(this);
        previewView.setController(cameraController);

        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        MlKitAnalyzer analyzer = new MlKitAnalyzer(
                Collections.singletonList(recognizer),
                COORDINATE_SYSTEM_VIEW_REFERENCED,
                analysisExecutor,
                result -> {
                    Text text = result.getValue(recognizer);
                    if (frozen) return;

                    if (text == null) {
                        runOnUiThread(() -> {
                            overlayView.clearHits();
                            statusText.setText("OCR activ • niciun text citit încă");
                        });
                        return;
                    }

                    TopicMap activeMap = topicMap == null
                            ? TopicMapStore.load(MainActivity.this)
                            : topicMap;

                    List<MatchHit> hits = TopicMatcher.find(
                            MainActivity.this,
                            text,
                            activeMap
                    );

                    int recognizedWords = countRecognizedWords(text);
                    int searchableTerms = countSearchableTerms(activeMap);
                    runOnUiThread(() -> applyHits(hits, recognizedWords, searchableTerms));
                }
        );

        cameraController.setImageAnalysisAnalyzer(analysisExecutor, analyzer);
        cameraController.bindToLifecycle(this);
    }

    private void applyHits(List<MatchHit> hits, int recognizedWords, int searchableTerms) {
        if (frozen) return;
        overlayView.updateHits(
                hits,
                AppPrefs.precision(this),
                AppPrefs.showLabels(this)
        );

        Set<String> nodes = new HashSet<>();
        for (MatchHit hit : hits) nodes.add(hit.node.path);

        if (searchableTerms <= 0) {
            statusText.setText("OCR: " + recognizedWords + " cuvinte • adaugă un nod/termen în HARTĂ");
            return;
        }

        if (recognizedWords <= 0) {
            statusText.setText("OCR activ • apropie camera și ține textul clar");
            return;
        }

        if (hits.isEmpty()) {
            statusText.setText("OCR: " + recognizedWords + " cuvinte • 0 potriviri");
        } else {
            statusText.setText(
                    "OCR: " + recognizedWords + " cuvinte • " +
                            hits.size() + " potriviri • " + nodes.size() + " noduri"
            );
            maybeFeedback(hits, nodes);
        }
    }

    private int countRecognizedWords(Text text) {
        int count = 0;
        if (text == null) return 0;
        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                count += line.getElements().size();
            }
        }
        return count;
    }

    private int countSearchableTerms(TopicMap map) {
        if (map == null) return 0;
        int count = 0;
        for (TopicNode node : map.nodes) {
            if (!node.enabled) continue;
            count += Math.max(1, node.terms.size());
        }
        return count;
    }

    private void maybeFeedback(List<MatchHit> hits, Set<String> nodes) {
        long now = System.currentTimeMillis();
        String signature = nodes.toString() + "|" + Math.min(9, hits.size());
        if (signature.equals(lastFeedbackSignature) && now - lastFeedbackAt < 1200L) return;
        if (now - lastFeedbackAt < 650L) return;

        lastFeedbackSignature = signature;
        lastFeedbackAt = now;

        if (AppPrefs.haptic(this)) {
            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                int amplitude = Math.min(150, 45 + nodes.size() * 18 + hits.size() * 4);
                if (Build.VERSION.SDK_INT >= 26) {
                    vibrator.vibrate(VibrationEffect.createOneShot(24L, amplitude));
                } else {
                    vibrator.vibrate(24L);
                }
            }
        }

        if (AppPrefs.sound(this) && toneGenerator != null) {
            toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP, 45);
        }
    }

    private void toggleFreeze() {
        if (!frozen) {
            Bitmap bitmap = previewView.getBitmap();
            if (bitmap == null) {
                toast("Camera nu are încă un cadru disponibil.");
                return;
            }

            Bitmap composite = Bitmap.createBitmap(
                    Math.max(1, previewView.getWidth()),
                    Math.max(1, previewView.getHeight()),
                    Bitmap.Config.ARGB_8888
            );
            Canvas canvas = new Canvas(composite);
            canvas.drawBitmap(
                    bitmap,
                    null,
                    new Rect(0, 0, composite.getWidth(), composite.getHeight()),
                    null
            );
            overlayView.draw(canvas);

            frozenBitmap = composite;
            frozen = true;
            freezeImage.setImageBitmap(frozenBitmap);
            freezeImage.setVisibility(View.VISIBLE);
            overlayView.setVisibility(View.GONE);
            freezeButton.setText("REIA");
            statusText.setText("Cadru înghețat • nimic nu este salvat automat");
        } else {
            frozen = false;
            frozenBitmap = null;
            freezeImage.setImageDrawable(null);
            freezeImage.setVisibility(View.GONE);
            overlayView.setVisibility(View.VISIBLE);
            freezeButton.setText("ÎNGHEAȚĂ");
            statusText.setText("Scanare live reluată");
        }
    }

    private void saveFrozenFrame() {
        if (!frozen || frozenBitmap == null) {
            toast("Îngheață mai întâi cadrul pe care vrei să-l salvezi.");
            return;
        }

        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.setType("image/png");
        intent.putExtra(Intent.EXTRA_TITLE, "BiblioTopicSearch_cadru.png");
        startActivityForResult(intent, REQ_SAVE_FRAME);
    }

    private void toggleTorch() {
        if (cameraController == null) {
            toast("Camera nu este încă pregătită.");
            return;
        }

        torchEnabled = !torchEnabled;
        cameraController.enableTorch(torchEnabled);
        torchButton.setText(torchEnabled ? "STINGE" : "LANTERNĂ");
    }

    private void showHitDetails(MatchHit hit) {
        DictionaryStore store = new DictionaryStore(this);
        DictionaryStore.Entry entry = store.lookup(hit.originalText);
        if (entry == null) entry = store.lookup(hit.searchTerm);

        StringBuilder message = new StringBuilder();
        message.append("Nod: ").append(hit.node.path)
                .append("\nTermen căutat: ").append(hit.searchTerm)
                .append("\nText OCR: ").append(hit.originalText);

        if (entry != null) {
            message.append("\n\nDEFINIȚIE\n").append(entry.definition);
            if (!entry.synonyms.isEmpty()) message.append("\n\nSinonime: ").append(entry.synonyms);
            if (!entry.antonyms.isEmpty()) message.append("\nAntonime: ").append(entry.antonyms);
            if (!entry.source.isEmpty()) message.append("\nSursă dicționar: ").append(entry.source);
        } else {
            message.append("\n\nNu există o intrare în dicționarul local pentru acest termen.");
        }

        new AlertDialog.Builder(this)
                .setTitle(hit.originalText)
                .setMessage(message.toString())
                .setPositiveButton("Închide", null)
                .show();
    }

    private int activeNodeCount(TopicMap map) {
        int count = 0;
        if (map != null) {
            for (TopicNode node : map.nodes) if (node.enabled) count++;
        }
        return count;
    }

    private Button actionButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(10);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(53, 92, 125)));
        return button;
    }

    private LinearLayout.LayoutParams weightedButton() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private FrameLayout.LayoutParams match() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String text) {
        android.widget.Toast.makeText(this, text, android.widget.Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_SAVE_FRAME || resultCode != RESULT_OK ||
                data == null || data.getData() == null || frozenBitmap == null) {
            return;
        }

        Uri uri = data.getData();
        try {
            OutputStream output = getContentResolver().openOutputStream(uri, "wt");
            if (output == null) throw new IllegalStateException("Nu pot deschide destinația.");
            try (OutputStream out = output) {
                frozenBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            }
            toast("Cadrul a fost salvat.");
        } catch (Exception e) {
            toast("Salvare eșuată: " + e.getMessage());
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setupCamera();
            } else {
                statusText.setText("Permisiunea camerei este necesară pentru OCR live.");
            }
        }
    }
}
