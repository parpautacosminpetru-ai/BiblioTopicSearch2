package ro.bibliotopicsearch.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class OverlayView extends View {
    public interface OnHitTapListener {
        void onHitTap(MatchHit hit);
    }

    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelSubPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelBackgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelConnectorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private List<MatchHit> hits = new ArrayList<>();
    private Set<String> previousOccurrenceKeys = new HashSet<>();
    private Set<String> flashingOccurrenceKeys = new HashSet<>();
    private long flashUntil = 0L;
    private boolean showLabels = true;
    private OnHitTapListener tapListener;

    public OverlayView(Context context) {
        super(context);
        init();
    }

    public OverlayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setWillNotDraw(false);
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(dp(2.5f));

        labelPaint.setColor(Color.WHITE);
        labelPaint.setTextSize(sp(13));
        labelPaint.setFakeBoldText(true);

        labelSubPaint.setColor(Color.argb(235, 255, 255, 255));
        labelSubPaint.setTextSize(sp(9.5f));

        labelConnectorPaint.setStyle(Paint.Style.STROKE);
        labelConnectorPaint.setStrokeWidth(dp(2f));
    }

    public void setOnHitTapListener(OnHitTapListener listener) {
        tapListener = listener;
    }

    public void clearHits() {
        hits = new ArrayList<>();
        previousOccurrenceKeys.clear();
        flashingOccurrenceKeys.clear();
        invalidate();
    }

    public List<MatchHit> getHitsSnapshot() {
        return new ArrayList<>(hits);
    }

    /**
     * 100 = coordonatele OCR curente au prioritate maximă (precizie mare).
     * Valori mai mici aplică mai multă netezire și păstrează foarte scurt o
     * potrivire dacă OCR-ul o ratează într-un singur cadru.
     */
    public void updateHits(List<MatchHit> incoming, int precision, boolean labels) {
        showLabels = labels;
        List<MatchHit> old = hits;
        List<MatchHit> adjusted = new ArrayList<>();
        Set<Integer> usedOld = new HashSet<>();

        int safePrecision = Math.max(0, Math.min(100, precision));
        float currentWeight = 0.35f + 0.65f * (safePrecision / 100f);
        float maxDistance = dp(34f + (100 - safePrecision) * 0.55f);
        long holdMs = 70L + (100 - safePrecision) * 2L;
        long now = System.currentTimeMillis();

        for (MatchHit fresh : incoming) {
            MatchHit nearest = null;
            int nearestIndex = -1;
            float nearestDistance = Float.MAX_VALUE;

            for (int i = 0; i < old.size(); i++) {
                if (usedOld.contains(i)) continue;
                MatchHit previous = old.get(i);
                if (!previous.identityKey().equals(fresh.identityKey())) continue;

                float dx = previous.box.centerX() - fresh.box.centerX();
                float dy = previous.box.centerY() - fresh.box.centerY();
                float distance = (float) Math.sqrt(dx * dx + dy * dy);
                if (distance < nearestDistance && distance <= maxDistance) {
                    nearestDistance = distance;
                    nearest = previous;
                    nearestIndex = i;
                }
            }

            if (nearest != null) {
                usedOld.add(nearestIndex);
                fresh.box = blend(nearest.box, fresh.box, currentWeight);
            }
            adjusted.add(fresh);
        }

        // Evită pâlpâirea când OCR-ul pierde termenul pentru un singur cadru.
        for (int i = 0; i < old.size(); i++) {
            if (usedOld.contains(i)) continue;
            MatchHit previous = old.get(i);
            if (now - previous.detectedAt <= holdMs) {
                adjusted.add(previous);
            }
        }

        Set<String> nowKeys = occurrenceKeys(adjusted);
        Set<String> newKeys = new HashSet<>(nowKeys);
        newKeys.removeAll(previousOccurrenceKeys);
        if (!newKeys.isEmpty()) {
            flashingOccurrenceKeys = newKeys;
            flashUntil = now + 220L;
        }
        previousOccurrenceKeys = nowKeys;
        hits = adjusted;
        invalidate();

        if (flashUntil > now) {
            postInvalidateDelayed(70L);
        }
    }

    private RectF blend(RectF oldBox, RectF newBox, float currentWeight) {
        float previousWeight = 1f - currentWeight;
        return new RectF(
                oldBox.left * previousWeight + newBox.left * currentWeight,
                oldBox.top * previousWeight + newBox.top * currentWeight,
                oldBox.right * previousWeight + newBox.right * currentWeight,
                oldBox.bottom * previousWeight + newBox.bottom * currentWeight
        );
    }

    private Set<String> occurrenceKeys(List<MatchHit> values) {
        Set<String> keys = new HashSet<>();
        for (MatchHit hit : values) {
            keys.add(occurrenceKey(hit));
        }
        return keys;
    }

    private String occurrenceKey(MatchHit hit) {
        int x = Math.round(hit.box.centerX() / Math.max(1f, dp(8)));
        int y = Math.round(hit.box.centerY() / Math.max(1f, dp(8)));
        return hit.identityKey() + "|" + x + "|" + y;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        long now = System.currentTimeMillis();
        boolean flashActive = now < flashUntil;

        for (MatchHit hit : hits) {
            int color = hit.node.color;
            boolean flashing = flashActive && flashingOccurrenceKeys.contains(occurrenceKey(hit));

            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(withAlpha(color, flashing ? 100 : 58));
            strokePaint.setColor(withAlpha(color, 245));
            strokePaint.setStrokeWidth(dp(flashing ? 4f : 2.5f));

            RectF box = new RectF(hit.box);
            float padX = dp(2);
            float padY = dp(1.5f);
            box.inset(-padX, -padY);

            canvas.drawRoundRect(box, dp(4), dp(4), fillPaint);
            canvas.drawRoundRect(box, dp(4), dp(4), strokePaint);

            if (showLabels) {
                drawLabel(canvas, hit, box);
            }
        }

        if (flashActive) {
            postInvalidateDelayed(70L);
        }
    }

    private void drawLabel(Canvas canvas, MatchHit hit, RectF box) {
        String symbol = hit.node.symbol == null ? "" : hit.node.symbol.trim();
        String term = hit.searchTerm == null ? "" : hit.searchTerm.trim();
        String path = hit.node.path == null ? hit.node.title : hit.node.path;

        String main = (symbol.isEmpty() ? "" : symbol + " ") + ellipsizeEnd(term, 30);
        String sub = ellipsizeStart(path == null ? "" : path, 42);

        float textWidth = Math.max(labelPaint.measureText(main), labelSubPaint.measureText(sub));
        float width = textWidth + dp(12);
        float height = sub.isEmpty() ? dp(24) : dp(38);

        float left = box.left;
        if (left + width > getWidth() - dp(4)) left = getWidth() - width - dp(4);
        left = Math.max(dp(4), left);

        float bottom = box.top - dp(3);
        float top = bottom - height;
        if (top < dp(4)) {
            top = box.bottom + dp(3);
            bottom = top + height;
        }

        RectF tag = new RectF(left, top, left + width, bottom);

        // Mică legătură vizuală între etichetă și cuvânt: eticheta funcționează
        // ca un steguleț colorat ancorat de locul exact detectat de OCR.
        boolean tagAbove = tag.bottom <= box.top;
        labelConnectorPaint.setColor(withAlpha(hit.node.color, 245));
        canvas.drawLine(
                tag.centerX(),
                tagAbove ? tag.bottom : tag.top,
                box.centerX(),
                tagAbove ? box.top : box.bottom,
                labelConnectorPaint
        );

        labelBackgroundPaint.setColor(withAlpha(hit.node.color, 238));
        canvas.drawRoundRect(tag, dp(6), dp(6), labelBackgroundPaint);

        float mainBaseline;
        if (sub.isEmpty()) {
            mainBaseline = tag.centerY() - (labelPaint.ascent() + labelPaint.descent()) / 2f;
        } else {
            mainBaseline = tag.top + dp(15);
        }
        canvas.drawText(main, tag.left + dp(6), mainBaseline, labelPaint);

        if (!sub.isEmpty()) {
            float subBaseline = tag.bottom - dp(6);
            canvas.drawText(sub, tag.left + dp(6), subBaseline, labelSubPaint);
        }
    }

    private String ellipsizeEnd(String value, int maxChars) {
        if (value == null) return "";
        if (value.length() <= maxChars) return value;
        return value.substring(0, Math.max(1, maxChars - 1)) + "…";
    }

    private String ellipsizeStart(String value, int maxChars) {
        if (value == null) return "";
        if (value.length() <= maxChars) return value;
        return "…" + value.substring(value.length() - Math.max(1, maxChars - 1));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_UP) {
            float x = event.getX();
            float y = event.getY();
            for (int i = hits.size() - 1; i >= 0; i--) {
                MatchHit hit = hits.get(i);
                RectF expanded = new RectF(hit.box);
                expanded.inset(-dp(8), -dp(8));
                if (expanded.contains(x, y)) {
                    if (tapListener != null) tapListener.onHitTap(hit);
                    performClick();
                    return true;
                }
            }
        }
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private float sp(float value) {
        return value * getResources().getDisplayMetrics().scaledDensity;
    }
}
